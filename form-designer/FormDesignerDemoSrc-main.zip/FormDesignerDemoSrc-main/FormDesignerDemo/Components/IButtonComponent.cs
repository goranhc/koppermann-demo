﻿using Applications.Shared;
using Microsoft.AspNetCore.Components;
using System.Collections.Generic;

namespace Applications.Client.Components {
	public interface IButtonComponent {
		List<ButtonDto> Btns { get; set; }
		EventCallback<int> OnClick { get; set; }
	}
}
