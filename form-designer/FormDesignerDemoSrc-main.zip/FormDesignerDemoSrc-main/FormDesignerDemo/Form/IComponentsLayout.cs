﻿using System.Collections.Generic;

namespace Applications.Client.Form {
	interface IComponentsLayout {
		Dictionary<string, List<Component>> Places { get; }
	}
}
