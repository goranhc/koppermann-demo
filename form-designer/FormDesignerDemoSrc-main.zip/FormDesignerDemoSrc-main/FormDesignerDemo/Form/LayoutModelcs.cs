﻿using Applications.Shared;
using System.Collections.Generic;

namespace Applications.Client.Form {
	public class LayoutModel {
        public Dictionary<string, object> ModelData { get; set; }
        public List<ButtonDto> Btns { get; set; }
        public Dictionary<string, List<Component>> Places { get; set; }
    }
}
