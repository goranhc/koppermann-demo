﻿using System;
using System.Collections.Generic;

namespace Applications.Client.Form {
    /// <summary>
    /// Описание динамического компонента
    /// </summary>
    public class Component {
        public Type Type { get; set; }
        public Dictionary<string, object> Parameters { get; set; }

        public Component(Type type, Dictionary<string, object> parameters = null) {
            Type = type ?? throw new ArgumentNullException(nameof(type));
            Parameters = parameters;
        }
    }

    /// <summary>
    /// Обертка для динамического компонента со свойствами для UI
    /// </summary>
    public class ComponentBox {
        public ComponentBox(Component component) {
            Component = component;
        }
        public Component Component { get; set; }

        bool isHover;
        public bool IsHover {
            get => isHover;
            set {
                isHover = value;
                IsHighlighted = isHover || isSelected;
            }
        }

        bool isSelected;
        public bool IsSelected {
            get => isSelected;
            set {
                isSelected = value;
                IsHighlighted = isHover || isSelected;
            }
        }

        public bool IsHighlighted { get; private set; }
    }


    static class ComponentExtension {
        public static void PropertyUpdate(this Component comp, string propName, object val) {
            if (comp.Parameters == null)
                comp.Parameters = new Dictionary<string, object>();

            if (!comp.Parameters.ContainsKey(propName))
                comp.Parameters.Add(propName, val);
            else
                comp.Parameters[propName] = val;
        }
    }

    static class ComponentBoxExtension {
        public static T PropertyGet<T>(this ComponentBox compBox, string propName) {
            if (compBox.Component.Parameters == null ||
                !compBox.Component.Parameters.ContainsKey(propName))
                return default;

            return (T)compBox.Component.Parameters[propName];
        }

        public static void PropertyUpdate(this ComponentBox compBox, string propName, object val) {
            compBox.Component.PropertyUpdate(propName, val);
        }
    }
}
