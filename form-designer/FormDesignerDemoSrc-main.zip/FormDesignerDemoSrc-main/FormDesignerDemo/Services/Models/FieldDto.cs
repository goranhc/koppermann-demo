﻿namespace Applications.Shared {
	public class FieldDto {
		public string Id { get; set; }
		public string Title { get; set; }
		public FieldTypeDto FieldType { get; set; }
	}

	public enum FieldTypeDto {
		Text = 1,
		Bool = 2
	}
}
