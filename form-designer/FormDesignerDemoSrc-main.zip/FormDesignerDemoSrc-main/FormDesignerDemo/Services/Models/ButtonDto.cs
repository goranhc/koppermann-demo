﻿namespace Applications.Shared {
	public class ButtonDto {
		public string Title { get; set; }
		public int Action { get; set; }
		public bool IsPrimary { get; set; }
	}
}
