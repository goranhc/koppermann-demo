﻿using System.Collections.Generic;

namespace Applications.Client.Components {
	public interface IModelComponent {
		Dictionary<string, object> ModelData { set; }
	}
}
