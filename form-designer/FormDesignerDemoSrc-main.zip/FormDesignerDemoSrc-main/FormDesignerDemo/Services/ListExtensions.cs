﻿using System.Collections.Generic;
using System.Linq;

namespace Applications.Client.Services {
	static class ListHelper {
		public static void AddRange<T>(ref List<T> to, List<T> vals) {
			if (vals?.Any() != true)
				return;

			if (to != null)
				to.AddRange(vals);
			else
				to = vals.ToList();
		}

		public static void Set<TKey, TVal>(this Dictionary<TKey, TVal> dic, TKey key, TVal val) {
			if (!dic.ContainsKey(key))
				dic.Add(key, val);
			else
				dic[key] = val;
		}
	}
}
