﻿using Applications.Shared;
using System.Collections.Generic;

namespace Applications.Client.Form.Settings {
	public interface IModelFieldsComponent {
		List<FieldDto> ModelFields { set; }
	}
}
