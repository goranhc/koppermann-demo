using Applications.Client.Form;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

namespace FormDesignerDemo {
	public class Program {
		public static async Task Main(string[] args) {
			var builder = WebAssemblyHostBuilder.CreateDefault(args);
			builder.RootComponents.Add<App>("#app");

			builder.Services
				.AddSingleton<CompBoxSelectService>()
				.AddSingleton<ICompBoxSettingsUpdateService>(ff => ff.GetRequiredService<CompBoxSelectService>());

			await builder.Build().RunAsync();
		}
	}
}
