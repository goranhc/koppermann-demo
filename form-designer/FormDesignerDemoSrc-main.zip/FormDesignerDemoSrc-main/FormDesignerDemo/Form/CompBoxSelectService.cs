﻿using System;
using static Applications.Client.Form.CompBoxSelectService; 

namespace Applications.Client.Form {
    /// <summary>
    /// Подписка и fire события изменения параметров динамического комопнента
    /// </summary>
    public interface ICompBoxSettingsUpdateService {
        void Fire(CompBoxEvent evt);
    }

    /// <summary>
    /// UI сервис выбранного для редактирования компонента
    /// </summary>
    public class CompBoxSelectService : ICompBoxSettingsUpdateService {
        public event EventHandler<ComponentBox> OnSelect;
        public event EventHandler<CompBoxEvent> On;
        public void FireSelected(ComponentBox compBox) {
            OnSelect?.Invoke(this, compBox);
        }
        public void Fire(CompBoxEvent evt) {
            On?.Invoke(this, evt);
        }


        public class CompBoxEvent {
            public CompBoxEventType EvtType { get; set; }
            public ComponentBox CompBox { get; set; }

            public CompBoxEvent(CompBoxEventType evtType, ComponentBox compBox) {
                EvtType = evtType;
                CompBox = compBox;
            }
        }

        public enum CompBoxEventType {
            Update,
            Cancel,
            Delete,
        }
    }
}
